import os
import numpy as np
import cupy as cp
import sys
import time
import math

import opt_einsum as oe
from itertools import product

from tools.linalg_tools import svd, eigh

def tensor_legs_rearrange(T, do_what:str, direction:str):
    """
    Parameters
    ----------
    `T` : Tensor T_{xXyY}
    >>>      Y
    >>>      |
    >>>  x---T---X
    >>>      |
    >>>      y

    `do_what` : "transpose" or "restore"
    `direction` : "x" or "X", x direction; "y" or "Y", y direction. 

    ----------
    """
    if do_what == "transpose":
        if direction == "Y" or direction == "y":
            return T
        elif direction == "X" or direction == "x":
            T = cp.transpose(T, axes=(2,3,0,1))
            return T
        
    elif do_what == "restore":
        if direction == "Y" or direction == "y":
            return T
        elif direction == "X" or direction == "x":
            T = cp.transpose(T, axes=(2,3,0,1))
            return T
