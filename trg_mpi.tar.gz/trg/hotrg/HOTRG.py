from mpi4py import MPI 
from tools.mpi_tools import mapping_infomation, gpu_syn

try:
    import cupy as cp
except:
    pass
import numpy as np

class Tensor_HOTRG:
    def __init__(self, dim, Dcut, comm:MPI.Intercomm):
        #basic data----------
        self.dim = dim
        self.Dcut = Dcut
        self.WORLD_COMM = comm
        self.WORLD_RANK = comm.Get_rank()

        #need to be initialized---
        self.T         = None
        self.is_impure = False
        self.coor      = None

        self.map_info = None
        self.chunk_shape = None

        self.type  = None
        self.shape = None
        self.ndim  = None
        #-------------------------

    def import_from_dist_tensor(self, Tdist, shape:tuple, chunk:tuple, map_info:list, is_impure=False, coor=None):
        if type(Tdist) == np.ndarray:
            xp = np
            usegpu = False
        elif type(Tdist) == cp.ndarray:
            xp = cp
            usegpu = True
        else:
            raise SystemExit("Only suppose ndarray of numpy or cupy.")
        
        if is_impure:
            assert coor is not None, "Coordinate of impure tensor is needed."
        
        WORLD_COMM = self.WORLD_COMM
        WORLD_SIZE = WORLD_COMM.Get_size()
        WORLD_RANK = WORLD_COMM.Get_rank()

        assert len(chunk) == 2*self.dim, "chunk dimension must mach system dimension."

        self.T = Tdist
        self.map_info = map_info
        self.ndim  = Tdist.ndim
        self.shape = shape
        self.type  = type(Tdist)
        self.chunk_shape = chunk
        self.is_impure   = is_impure
        self.coor        = coor

    def init_dist_tensor(self, T, chunk:tuple, is_impure=False, coor=None):
        if type(T) == np.ndarray:
            xp = np
            usegpu = False
        elif type(T) == cp.ndarray:
            xp = cp
            usegpu = True
        else:
            raise SystemExit("Only suppose ndarray of numpy or cupy.")
        
        if is_impure:
            assert coor is not None, "Coordinate of impure tensor is needed."
        
        WORLD_COMM = self.WORLD_COMM
        WORLD_SIZE = WORLD_COMM.Get_size()
        WORLD_RANK = WORLD_COMM.Get_rank()

        assert len(chunk) == 2*self.dim, "chunk dimension must mach system dimension."

        
        if WORLD_RANK == 0:
            assert T.ndim == len(chunk), "chunk dimension must mach tensor dimension"
            self.ndim  = T.ndim
            self.shape = T.shape
            self.type  = type(T)

        self.shape = WORLD_COMM.bcast(obj=self.ndim,  root=0)
        self.shape = WORLD_COMM.bcast(obj=self.shape, root=0)
        self.type  = WORLD_COMM.bcast(obj=self.type,  root=0)
        self.chunk_shape = chunk
        self.is_impure   = is_impure
        self.coor        = coor

        self.map_info = mapping_infomation(shape=self.shape, chunk=self.chunk_shape, comm=WORLD_COMM)
        T_local = None
        if WORLD_RANK == 0:
            T_local = [[] for _ in range(WORLD_SIZE)]
            for rank in range(WORLD_SIZE):
                for s in self.map_info:
                    T_local[rank].append(T[s])
        self.T = WORLD_COMM.scatter(sendobj=T_local, root=0)
        del T_local
        gpu_syn(usegpu)
        WORLD_COMM.barrier()


    def transpose(self, axes:tuple):
        

        

#class HOTRG_2d:
#    def __init__(self, Dcut, renormalization_group_iteration, squzzer_type, Tpure, Timpure, operator, save):
#        pass
#
#
#    def pure_tensor_renormalization(self):
